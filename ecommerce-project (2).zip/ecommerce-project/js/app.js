import { fetchProducts } from './api.js';
import { ShoppingCart } from './cart.js';
import { KEYS, load, save } from './storage.js';
import * as ui from './ui.js';

const $ = id => document.getElementById(id);

/* ---------- الحالة ---------- */
const cart = new ShoppingCart();
let products = [];
let wishlist = load(KEYS.wishlist, []);

const state = {
  category: 'all',
  maxPrice: Infinity,
  query: '',
  sort: 'default',
  view: 'home' // home | wishlist
};

/* ---------- أدوات مساعدة ---------- */
function debounce(fn, delay = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

const findProduct = id => products.find(p => p.id === Number(id));

/* ---------- المظهر ---------- */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  save(KEYS.theme, theme);
}

function initTheme() {
  const saved = load(KEYS.theme, null);
  const preferred = window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(saved || preferred);
}

/* ---------- الفلترة والعرض ---------- */
function getVisibleProducts() {
  const q = state.query.trim().toLowerCase();

  let list = products
    .filter(p => state.category === 'all' || p.category === state.category)
    .filter(p => p.price <= state.maxPrice)
    .filter(p => !q || p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q))
    .filter(p => state.view !== 'wishlist' || wishlist.includes(p.id));

  const sorters = {
    'price-asc': (a, b) => a.price - b.price,
    'price-desc': (a, b) => b.price - a.price,
    'rating-desc': (a, b) => b.rating.rate - a.rating.rate
  };
  if (sorters[state.sort]) list = [...list].sort(sorters[state.sort]);

  return list;
}

function render() {
  const list = getVisibleProducts();
  ui.renderProducts(list, wishlist);
  ui.renderResultsInfo(`عدد المنتجات المعروضة: ${list.length}`);
  if (state.view === 'wishlist' && !list.length && !state.query) {
    $('products-grid').innerHTML = `
      <div class="state-box"><div class="big">💔</div><p>قائمة المفضلة فارغة. اضغط على القلب لإضافة منتجات.</p></div>`;
  }
}

function setupPriceSlider() {
  const max = Math.ceil(Math.max(...products.map(p => p.price)));
  const slider = $('price-range');
  slider.max = max;
  slider.value = max;
  state.maxPrice = max;
  $('price-value').textContent = max;
}

/* ---------- التنقل (Hash Routing) ---------- */
function handleRoute() {
  const hash = window.location.hash || '#/';
  state.view = hash.startsWith('#/wishlist') ? 'wishlist' : 'home';

  $('link-home').classList.toggle('active', state.view === 'home');
  $('link-wishlist').classList.toggle('active', state.view === 'wishlist');
  $('page-title').textContent = state.view === 'wishlist' ? 'قائمة المفضلة ❤️' : 'اكتشف أفضل المنتجات';

  if (products.length) render();
}

/* ---------- المفضلة ---------- */
function toggleWishlist(id) {
  id = Number(id);
  const exists = wishlist.includes(id);
  wishlist = exists ? wishlist.filter(w => w !== id) : [...wishlist, id];
  save(KEYS.wishlist, wishlist);
  $('wishlist-count').textContent = wishlist.length;
  ui.showToast(exists ? 'تمت الإزالة من المفضلة' : 'تمت الإضافة إلى المفضلة ❤️');
  render();

  const modal = $('product-modal');
  if (modal.open) ui.renderProductModal(findProduct(id), wishlist.includes(id));
}

/* ---------- السلة ---------- */
function addToCart(id) {
  const product = findProduct(id);
  if (!product) return;
  cart.addItem(product);
  ui.renderCart(cart);
  ui.showToast('تمت إضافة المنتج إلى السلة 🛒');
}

function openDetails(id) {
  const p = findProduct(id);
  if (!p) return;
  ui.renderProductModal(p, wishlist.includes(p.id));
  $('product-modal').showModal();
}

/* ---------- إتمام الطلب ---------- */
function openCheckout() {
  if (!cart.items.length) return;
  ui.closeDrawer();
  $('checkout-total').textContent = cart.getTotals().total;
  $('checkout-view').hidden = false;
  $('order-view').hidden = true;
  $('checkout-form').reset();
  $('checkout-form').querySelectorAll('.touched').forEach(el => el.classList.remove('touched'));
  $('checkout-modal').showModal();
}

function submitOrder(e) {
  e.preventDefault();
  const form = e.target;
  form.querySelectorAll('input, textarea').forEach(el => el.classList.add('touched'));

  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  const data = Object.fromEntries(new FormData(form));
  const order = {
    id: Date.now().toString(36).toUpperCase(),
    date: new Date().toISOString(),
    customer: data,
    items: cart.items.map(i => ({ ...i })),
    totals: cart.getTotals()
  };

  save(KEYS.lastOrder, order);
  cart.clear();
  ui.renderCart(cart);

  ui.renderOrderConfirmation(order);
  $('checkout-view').hidden = true;
  $('order-view').hidden = false;
}

function downloadInvoice(order) {
  const blob = new Blob([ui.buildInvoiceText(order)], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `invoice-${order.id}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ---------- ربط الأحداث ---------- */
function bindEvents() {
  // البحث الفوري مع Debounce
  $('search-input').addEventListener('input', debounce(e => {
    state.query = e.target.value;
    render();
  }, 300));

  // المظهر
  $('theme-toggle').addEventListener('click', () => {
    applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  });

  // الفئات
  $('category-filters').addEventListener('click', e => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.category = btn.dataset.category;
    render();
  });

  // السعر والترتيب
  $('price-range').addEventListener('input', e => {
    state.maxPrice = Number(e.target.value);
    $('price-value').textContent = e.target.value;
    render();
  });
  $('sort-select').addEventListener('change', e => {
    state.sort = e.target.value;
    render();
  });

  // شبكة المنتجات (تفويض الأحداث)
  $('products-grid').addEventListener('click', e => {
    if (e.target.id === 'retry-btn') return loadProducts();
    const el = e.target.closest('[data-action]');
    if (!el) return;
    const { action, id } = el.dataset;
    if (action === 'add') addToCart(id);
    else if (action === 'wish') toggleWishlist(id);
    else if (action === 'details') openDetails(id);
  });
  $('products-grid').addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.card-title')) {
      e.preventDefault();
      openDetails(e.target.dataset.id);
    }
  });

  // نافذة التفاصيل
  $('product-modal').addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (el) {
      if (el.dataset.action === 'add') addToCart(el.dataset.id);
      if (el.dataset.action === 'wish') toggleWishlist(el.dataset.id);
      return;
    }
    if (e.target === e.currentTarget) e.currentTarget.close(); // النقر على الخلفية
  });
  $('close-modal').addEventListener('click', () => $('product-modal').close());

  // السلة
  $('cart-btn').addEventListener('click', ui.openDrawer);
  $('close-cart').addEventListener('click', ui.closeDrawer);
  $('overlay').addEventListener('click', ui.closeDrawer);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && ui.isDrawerOpen()) ui.closeDrawer();
  });

  $('cart-items').addEventListener('click', e => {
    const btn = e.target.closest('[data-cart]');
    if (!btn) return;
    const id = Number(btn.dataset.id);
    const { cart: action } = btn.dataset;
    if (action === 'inc') cart.updateQuantity(id, 1);
    else if (action === 'dec') cart.updateQuantity(id, -1);
    else if (action === 'remove') cart.removeItem(id);
    ui.renderCart(cart);
  });

  // الكوبون
  const applyCoupon = () => {
    const code = $('coupon-input').value;
    if (!code.trim()) return ui.showToast('أدخل كود الخصم أولاً', 'error');
    if (cart.applyCoupon(code)) {
      ui.renderCart(cart);
      ui.showToast('تم تطبيق كوبون الخصم 🎉');
    } else {
      ui.showToast('كود الخصم غير صحيح', 'error');
    }
  };
  $('apply-coupon').addEventListener('click', applyCoupon);
  $('coupon-input').addEventListener('keydown', e => { if (e.key === 'Enter') applyCoupon(); });

  // إتمام الطلب
  $('checkout-btn').addEventListener('click', openCheckout);
  $('checkout-form').addEventListener('submit', submitOrder);
  $('checkout-form').addEventListener('blur', e => {
    if (e.target.matches('input, textarea')) e.target.classList.add('touched');
  }, true);
  $('cancel-checkout').addEventListener('click', () => $('checkout-modal').close());

  $('order-view').addEventListener('click', e => {
    const order = load(KEYS.lastOrder);
    if (e.target.id === 'print-invoice') window.print();
    if (e.target.id === 'download-invoice' && order) downloadInvoice(order);
    if (e.target.id === 'close-order') $('checkout-modal').close();
  });

  window.addEventListener('hashchange', handleRoute);
}

/* ---------- تحميل المنتجات ---------- */
async function loadProducts() {
  ui.renderSkeletons();
  ui.renderResultsInfo('جارٍ تحميل المنتجات...');
  try {
    const { products: data, offline } = await fetchProducts();
    products = data;
    setupPriceSlider();
    handleRoute();
    render();
    if (offline) ui.showToast('تعذّر الاتصال بالخادم، تم عرض بيانات تجريبية', 'error');
  } catch (err) {
    console.error(err);
    ui.renderError('حدث خطأ أثناء تحميل المنتجات.');
    ui.renderResultsInfo('');
  }
}

/* ---------- البداية ---------- */
function init() {
  initTheme();
  bindEvents();
  ui.renderCart(cart);
  $('wishlist-count').textContent = wishlist.length;
  loadProducts();
}

init();
