// جلب بيانات المنتجات من Fake Store API
const API_URL = 'https://fakestoreapi.com/products';
const USD_TO_SAR = 3.75; // تحويل الأسعار إلى الريال السعودي

// بيانات احتياطية تُستخدم عند فشل الاتصال (حتى يعمل المتجر دون إنترنت)
const FALLBACK_PRODUCTS = [
  { id: 1, title: 'حقيبة ظهر عملية للرحلات', price: 109.95, description: 'حقيبة ظهر متينة تتسع لحاسوب محمول حتى 15 بوصة، مثالية للسفر والدراسة.', category: "men's clothing", rating: { rate: 3.9, count: 120 } },
  { id: 2, title: 'قميص رجالي كاجوال', price: 22.3, description: 'قميص قطني مريح بتصميم عصري يناسب الاستخدام اليومي.', category: "men's clothing", rating: { rate: 4.1, count: 259 } },
  { id: 3, title: 'سوار فضي مرصع', price: 695, description: 'سوار فاخر بتصميم أنيق مرصع بأحجار لامعة.', category: 'jewelery', rating: { rate: 4.6, count: 400 } },
  { id: 4, title: 'خاتم ذهبي كلاسيكي', price: 168, description: 'خاتم ذهبي بتصميم كلاسيكي يناسب المناسبات الخاصة.', category: 'jewelery', rating: { rate: 3.9, count: 70 } },
  { id: 5, title: 'قرص تخزين خارجي 1 تيرا', price: 64, description: 'قرص تخزين محمول بسرعة نقل عالية وتوصيل USB 3.0.', category: 'electronics', rating: { rate: 3.3, count: 203 } },
  { id: 6, title: 'قرص SSD داخلي 256 جيجا', price: 109, description: 'قرص حالة صلبة سريع لتحسين أداء الحاسوب وتقليل زمن الإقلاع.', category: 'electronics', rating: { rate: 2.9, count: 470 } },
  { id: 7, title: 'جاكيت نسائي شتوي', price: 56.99, description: 'جاكيت دافئ بتصميم عصري مقاوم للرياح.', category: "women's clothing", rating: { rate: 4.7, count: 130 } },
  { id: 8, title: 'شاشة ألعاب منحنية 27 بوصة', price: 399.99, description: 'شاشة عالية معدل التحديث بألوان واضحة وتجربة لعب ممتعة.', category: 'electronics', rating: { rate: 4.8, count: 319 } }
];

function normalize(p) {
  return {
    id: Number(p.id),
    title: String(p.title),
    price: Math.round(Number(p.price) * USD_TO_SAR * 100) / 100,
    description: String(p.description || ''),
    category: String(p.category),
    image: p.image || '',
    rating: {
      rate: Number(p.rating?.rate) || 0,
      count: Number(p.rating?.count) || 0
    }
  };
}

export async function fetchProducts() {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(API_URL, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return { products: data.map(normalize), offline: false };
  } catch (err) {
    console.warn('تعذّر جلب المنتجات من الـ API، سيتم استخدام بيانات احتياطية:', err);
    return { products: FALLBACK_PRODUCTS.map(normalize), offline: true };
  }
}
