import { KEYS, load, save, remove } from './storage.js';

const COUPONS = { SAVE20: 0.2 };
const TAX_RATE = 0.15;

export class ShoppingCart {
  constructor() {
    this.items = load(KEYS.cart, []);
    this.couponCode = load(KEYS.coupon, '');
    this.discount = COUPONS[this.couponCode] || 0;
  }

  save() {
    save(KEYS.cart, this.items);
  }

  addItem(product) {
    const existing = this.items.find(item => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      const { id, title, price, image } = product;
      this.items.push({ id, title, price, image, quantity: 1 });
    }
    this.save();
  }

  updateQuantity(id, delta) {
    const item = this.items.find(item => item.id === id);
    if (!item) return;
    item.quantity += delta;
    if (item.quantity <= 0) {
      this.removeItem(id);
    } else {
      this.save();
    }
  }

  removeItem(id) {
    this.items = this.items.filter(item => item.id !== id);
    this.save();
  }

  clear() {
    this.items = [];
    this.couponCode = '';
    this.discount = 0;
    this.save();
    remove(KEYS.coupon);
  }

  applyCoupon(code) {
    const key = code.trim().toUpperCase();
    if (COUPONS[key]) {
      this.discount = COUPONS[key];
      this.couponCode = key;
      save(KEYS.coupon, key);
      return true;
    }
    return false;
  }

  getTotals() {
    const subtotal = this.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const discountAmount = subtotal * this.discount;
    const afterDiscount = subtotal - discountAmount;
    const tax = afterDiscount * TAX_RATE;
    const total = afterDiscount + tax;

    return {
      count: this.items.reduce((sum, item) => sum + item.quantity, 0),
      subtotal: subtotal.toFixed(2),
      discountAmount: discountAmount.toFixed(2),
      tax: tax.toFixed(2),
      total: total.toFixed(2)
    };
  }
}
