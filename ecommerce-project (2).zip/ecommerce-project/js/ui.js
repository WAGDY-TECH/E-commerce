// دوال بناء وعرض العناصر في الـ DOM
const $ = id => document.getElementById(id);

const CATEGORY_NAMES = {
  electronics: 'إلكترونيات',
  jewelery: 'مجوهرات',
  "men's clothing": 'ملابس رجالية',
  "women's clothing": 'ملابس نسائية'
};

const PLACEHOLDER_IMG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#e2e8f0"/><text x="100" y="110" font-size="48" text-anchor="middle">🛍️</text></svg>'
  );

export const money = n => Number(n).toFixed(2);
export const categoryName = c => CATEGORY_NAMES[c] || c;

export function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]));
}

function starsHtml(rate) {
  const full = Math.round(rate);
  return '★'.repeat(full) + '☆'.repeat(5 - full);
}

function imgTag(src, alt) {
  const safe = src ? escapeHtml(src) : PLACEHOLDER_IMG;
  return `<img src="${safe}" alt="${escapeHtml(alt)}" loading="lazy" onerror="this.onerror=null;this.src='${PLACEHOLDER_IMG}'">`;
}

/* ---------- المنتجات ---------- */
export function renderSkeletons(count = 8) {
  $('products-grid').innerHTML = Array.from({ length: count }, () => `
    <article class="product-card skeleton-card" aria-hidden="true">
      <div class="skeleton sk-img"></div>
      <div class="skeleton sk-line short"></div>
      <div class="skeleton sk-line"></div>
      <div class="skeleton sk-line mid"></div>
    </article>`).join('');
}

export function renderProducts(products, wishlistIds) {
  const grid = $('products-grid');
  if (!products.length) {
    grid.innerHTML = `
      <div class="state-box">
        <div class="big">🔍</div>
        <p>لا توجد منتجات مطابقة لبحثك.</p>
      </div>`;
    return;
  }

  grid.innerHTML = products.map((p, i) => {
    const wished = wishlistIds.includes(p.id);
    return `
    <article class="product-card" data-id="${p.id}" style="animation-delay:${Math.min(i, 12) * 40}ms">
      <div class="card-image" data-action="details" data-id="${p.id}">
        ${imgTag(p.image, p.title)}
        <button class="wish-btn" data-action="wish" data-id="${p.id}"
                aria-pressed="${wished}" aria-label="${wished ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}">
          ${wished ? '❤️' : '🤍'}
        </button>
      </div>
      <span class="card-category">${escapeHtml(categoryName(p.category))}</span>
      <h3 class="card-title" data-action="details" data-id="${p.id}" tabindex="0" role="button">${escapeHtml(p.title)}</h3>
      <div class="rating" aria-label="التقييم ${p.rating.rate} من 5">
        <span class="stars" aria-hidden="true">${starsHtml(p.rating.rate)}</span>
        <span>${p.rating.rate} (${p.rating.count})</span>
      </div>
      <div class="card-footer">
        <span class="price">${money(p.price)} <small>ر.س</small></span>
        <button class="primary-btn" data-action="add" data-id="${p.id}">إضافة للسلة</button>
      </div>
    </article>`;
  }).join('');
}

export function renderError(message) {
  $('products-grid').innerHTML = `
    <div class="state-box">
      <div class="big">⚠️</div>
      <p>${escapeHtml(message)}</p>
      <button class="primary-btn" id="retry-btn">إعادة المحاولة</button>
    </div>`;
}

export function renderResultsInfo(text) {
  $('results-info').textContent = text;
}

/* ---------- نافذة التفاصيل ---------- */
export function renderProductModal(p, wished) {
  $('modal-content').innerHTML = `
    <div class="modal-product">
      <div class="card-image">${imgTag(p.image, p.title)}</div>
      <div>
        <span class="card-category">${escapeHtml(categoryName(p.category))}</span>
        <h2>${escapeHtml(p.title)}</h2>
        <div class="rating">
          <span class="stars" aria-hidden="true">${starsHtml(p.rating.rate)}</span>
          <span>${p.rating.rate} (${p.rating.count} تقييم)</span>
        </div>
        <p>${escapeHtml(p.description)}</p>
        <div class="price">${money(p.price)} <small>ر.س</small></div>
      </div>
    </div>
    <div class="modal-actions">
      <button class="primary-btn" data-action="add" data-id="${p.id}">إضافة للسلة</button>
      <button class="secondary-btn" data-action="wish" data-id="${p.id}">
        ${wished ? '❤️ إزالة من المفضلة' : '🤍 إضافة للمفضلة'}
      </button>
    </div>`;
}

/* ---------- السلة ---------- */
export function renderCart(cart) {
  const container = $('cart-items');
  if (!cart.items.length) {
    container.innerHTML = `<div class="cart-empty"><div class="big" style="font-size:3rem">🛒</div><p>سلتك فارغة حالياً.</p></div>`;
  } else {
    container.innerHTML = cart.items.map(item => `
      <div class="cart-item" data-id="${item.id}">
        ${imgTag(item.image, item.title)}
        <div class="cart-item-info">
          <h4 class="cart-item-title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</h4>
          <span class="cart-item-price">${money(item.price)} ر.س</span>
          <div class="qty-controls">
            <button class="qty-btn" data-cart="dec" data-id="${item.id}" aria-label="تقليل الكمية">−</button>
            <span aria-live="polite">${item.quantity}</span>
            <button class="qty-btn" data-cart="inc" data-id="${item.id}" aria-label="زيادة الكمية">+</button>
            <button class="remove-btn" data-cart="remove" data-id="${item.id}" aria-label="حذف المنتج">🗑️</button>
          </div>
        </div>
      </div>`).join('');
  }

  const t = cart.getTotals();
  $('cart-count').textContent = t.count;
  $('sum-subtotal').textContent = t.subtotal;
  $('sum-discount').textContent = t.discountAmount;
  $('sum-tax').textContent = t.tax;
  $('cart-total').textContent = t.total;
  $('checkout-btn').disabled = !cart.items.length;
  $('coupon-input').value = cart.couponCode || '';
}

export function openDrawer() {
  const overlay = $('overlay');
  overlay.hidden = false;
  requestAnimationFrame(() => overlay.classList.add('show'));
  const drawer = $('cart-drawer');
  drawer.classList.add('open');
  drawer.setAttribute('aria-hidden', 'false');
  $('close-cart').focus();
}

export function closeDrawer() {
  const overlay = $('overlay');
  overlay.classList.remove('show');
  setTimeout(() => { if (!overlay.classList.contains('show')) overlay.hidden = true; }, 300);
  const drawer = $('cart-drawer');
  drawer.classList.remove('open');
  drawer.setAttribute('aria-hidden', 'true');
}

export const isDrawerOpen = () => $('cart-drawer').classList.contains('open');

/* ---------- الطلب ---------- */
export function renderOrderConfirmation(order) {
  $('order-view').innerHTML = `
    <div class="order-success">
      <div class="big">✅</div>
      <h2>تم استلام طلبك بنجاح!</h2>
      <p>رقم الطلب: <strong>#${escapeHtml(order.id)}</strong></p>
    </div>
    <div class="order-details">
      <p><strong>العميل:</strong> ${escapeHtml(order.customer.name)} — ${escapeHtml(order.customer.phone)}</p>
      <p><strong>العنوان:</strong> ${escapeHtml(order.customer.city)}، ${escapeHtml(order.customer.address)}</p>
      <ul>
        ${order.items.map(i => `<li>${escapeHtml(i.title)} × ${i.quantity} — ${money(i.price * i.quantity)} ر.س</li>`).join('')}
      </ul>
      <p>المجموع الفرعي: ${order.totals.subtotal} ر.س</p>
      <p>الخصم: ${order.totals.discountAmount} ر.س</p>
      <p>الضريبة (15%): ${order.totals.tax} ر.س</p>
      <p><strong>الإجمالي: ${order.totals.total} ر.س</strong></p>
    </div>
    <div class="form-actions no-print">
      <button class="primary-btn" id="print-invoice">🖨️ طباعة الفاتورة</button>
      <button class="secondary-btn" id="download-invoice">⬇️ تحميل كملف نصي</button>
      <button class="secondary-btn" id="close-order">إغلاق</button>
    </div>`;
}

export function buildInvoiceText(order) {
  const lines = [
    `فاتورة طلب #${order.id}`,
    `التاريخ: ${new Date(order.date).toLocaleString('ar-SA')}`,
    `العميل: ${order.customer.name} | ${order.customer.phone} | ${order.customer.email}`,
    `العنوان: ${order.customer.city}، ${order.customer.address}`,
    '----------------------------------------',
    ...order.items.map(i => `${i.title} × ${i.quantity} = ${money(i.price * i.quantity)} ر.س`),
    '----------------------------------------',
    `المجموع الفرعي: ${order.totals.subtotal} ر.س`,
    `الخصم: ${order.totals.discountAmount} ر.س`,
    `الضريبة (15%): ${order.totals.tax} ر.س`,
    `الإجمالي: ${order.totals.total} ر.س`
  ];
  return lines.join('\n');
}

/* ---------- الإشعارات ---------- */
export function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type === 'error' ? 'error' : ''}`;
  toast.textContent = message;
  $('toast-container').appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
