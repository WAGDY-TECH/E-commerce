// التعامل الآمن مع LocalStorage
export const KEYS = {
  cart: 'cart',
  coupon: 'coupon',
  wishlist: 'wishlist',
  theme: 'theme',
  lastOrder: 'lastOrder'
};

export function load(key, fallback = null) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* التخزين غير متاح (وضع التصفح الخاص مثلاً) */
  }
}

export function remove(key) {
  try {
    localStorage.removeItem(key);
  } catch {
    /* تجاهل */
  }
}
